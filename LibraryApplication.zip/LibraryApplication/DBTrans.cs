﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject
{
    public class DBTrans
    {
        public string dbPath;
        private SQLiteConnection conn;
       
        public DBTrans(string _dbPath)
        {
            this.dbPath = _dbPath;
        }
        public void Init()
        {
            conn = new SQLiteConnection(this.dbPath);
            conn.CreateTable<Library>();
            conn.CreateTable<Book>();
            conn.CreateTable<Barrow>();
        }
        public List<Library> GetLibrary()
        {
            Init();
            return conn.Table<Library>().ToList();
        }

        public List<Book> GetBook()
        {
            Init();
            return conn.Table<Book>().ToList();
        }

        public List<Barrow> GetBarrow()
        {
            Init();
            return conn.Table<Barrow>().ToList();
        }
        public void Add(Library library)
        {
            conn = new SQLiteConnection(this.dbPath);
            conn.Insert(library);
        }
        public void Add(Book book)
        {
            conn = new SQLiteConnection(this.dbPath);
            conn.Insert(book);
        }

        public void Add(Barrow barrow)
        {
            conn = new SQLiteConnection(this.dbPath);
            conn.Insert(barrow);
        }

        public void Delete(Barrow barrow)
        {
            conn = new SQLiteConnection(this.dbPath);
            conn.Delete(barrow);
        }
    }
}