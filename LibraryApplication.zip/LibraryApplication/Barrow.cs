﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject
{
    public class Barrow
    {
        [PrimaryKey, AutoIncrement]
        public int BarrowID { get; set; }
        public string TakenDate { get; set; }
        public string BroughtDate { get; set; }
        
        public string StudentName { get; set; }
        public string Surname { get; set; }
        public string Birthdate { get; set; }
        public string Gender { get; set; }
        public string Class { get; set; }

        public string BookName { get; set; }
        public string Pages { get; set; }
        public string Point { get; set; }
        

    }
}
